package programasListas;

public interface ILinkedOrderedList<ELEMENT> {
	 
    public void addInOrder(ELEMENT item);
}
