package objetos;

public class socio {

	private int numAsociado;
	private int dni;
	private String nombre;
	private String apellido;
	private String domicilio;
	private int telefono;
	private String estado;
	
	public socio(){
		}

	public socio(int numAsociado, int dni, String nombre, String apellido, String domicilio, int telefono,
			String estado) {
		this.numAsociado = numAsociado;
		this.dni = dni;
		this.nombre = nombre;
		this.apellido = apellido;
		this.domicilio = domicilio;
		this.telefono = telefono;
		this.estado = estado;
	}

	public int getNumAsociado() {
		return numAsociado;
	}

	public void setNumAsociado(int numAsociado) {
		this.numAsociado = numAsociado;
	}

	public int getDni() {
		return dni;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	
	
}
