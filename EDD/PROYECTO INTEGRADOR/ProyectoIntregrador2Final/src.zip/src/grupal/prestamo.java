package objetos;

public class prestamo {

	private int id;
	private int codigoLibro;
	private int numSocio;
	private String fPrestamo;
	private int plazo;
	private String fvencimiento;
	private String estado;
	private String fDeDevolucionYMUlta;
	
	public prestamo() {
		
	}

	public prestamo(int id, int codigoLibro, int numSocio, String fPrestamo, int plazo, String fvencimiento, String estado,
			String fDeDevolucionYMUlta) {
		
		this.id = id;
		this.codigoLibro = codigoLibro;
		this.numSocio = numSocio;
		this.fPrestamo = fPrestamo;
		this.plazo = plazo;
		this.fvencimiento = fvencimiento;
		this.estado = estado;
		this.fDeDevolucionYMUlta = fDeDevolucionYMUlta;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCodigoLibro() {
		return codigoLibro;
	}

	public void setCodigoLibro(int codigoLibro) {
		this.codigoLibro = codigoLibro;
	}

	public int getNumSocio() {
		return numSocio;
	}

	public void setNumSocio(int numSocio) {
		this.numSocio = numSocio;
	}

	public String getFecha() {
		return fPrestamo;
	}

	public void setFPrestamo(String fecha) {
		this.fPrestamo= fecha;
	}

	public int getPlazo() {
		return plazo;
	}

	public void setPlazo(int plazo) {
		this.plazo = plazo;
	}

	public String getFvencimiento() {
		return fvencimiento;
	}

	public void setFvencimiento(String fvencimiento) {
		this.fvencimiento = fvencimiento;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getfDeDevolucionYMUlta() {
		return fDeDevolucionYMUlta;
	}

	public void setfDeDevolucionYMUlta(String fDeDevolucionYMUlta) {
		this.fDeDevolucionYMUlta = fDeDevolucionYMUlta;
	}
	
	
	
}
