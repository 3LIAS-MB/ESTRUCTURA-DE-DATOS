package objetos;

import proyIntegradorII.logica.Helper;

public class libro {

	private int codigo;
	private String titulo;
	private String autor;
	private String editorial;
	private int anio;
	private String tematica;
	private double precio;
	
	public libro(){
		
	}

	public libro(int codigo, String titulo, String autor, String editorial, int anio, String tematica, double precio) {
		
		this.codigo = codigo;
		this.titulo = titulo;
		this.autor = autor;
		this.editorial = editorial;
		this.anio = anio;
		this.tematica = tematica;
		this.precio = precio;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	public int getAnio() {
		return anio;
	}

	public void setAnio(int anio) {
		this.anio = anio;
	}

	public String getTematica() {
		return tematica;
	}

	public void setTematica(String tematica) {
		this.tematica = tematica;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	public void Altalibro() {
		char resp ;
		do{
			
			
			
			resp = Helper.yesOrNo("¿Cntinua? S/N");
		}while( resp =='N');
		
	}
}
